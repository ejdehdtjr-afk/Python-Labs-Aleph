#flask-board
!228 ar.conf
restart-ossec0 - restart-ossec.sh - 0
restart-ossec0 - restart-ossec.cmd - 0
restart-wazuh0 - restart-ossec.sh - 0
restart-wazuh0 - restart-ossec.cmd - 0
restart-wazuh0 - restart-wazuh - 0
restart-wazuh0 - restart-wazuh.exe - 0
!339 agent.conf
﻿<agent_config os="Windows">
  <localfile>
    <location>D:\Aleph\Python-Lab-ALeph-T\_7_board_test\logs\security.log</location>
    <log_format>syslog</log_format>
  </localfile>

  <syscheck>
    <directories realtime="yes" check_all="yes">D:\Aleph\Python-Lab-ALeph-T\_7_board_test\templates</directories>
  </syscheck>
</agent_config>
